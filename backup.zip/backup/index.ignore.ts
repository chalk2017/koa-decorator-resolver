
import * as Koa from 'koa';
import { print } from './util/console';
import * as WebSocket from 'koa-websocket';
// import * as bodyParser from 'koa-bodyparser';
import { wsRouter, router } from './routes';
import * as koaBody from 'koa-body';

const app = WebSocket(new Koa());

app.use(koaBody({
    multipart: true,
    formidable: {
        maxFileSize: 10000 * 1024 * 1024    // 设置上传文件大小最大限制，默认10M
    }
}))
// app.use(bodyParser());
app.use(router.routes());
app.ws.use(wsRouter.routes()).use(wsRouter.allowedMethods());
app.listen(8091, () => {
    print.info('Listen on 8091');
});
