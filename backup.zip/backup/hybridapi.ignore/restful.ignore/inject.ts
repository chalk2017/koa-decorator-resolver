/**
 * author: Chalk Yu
 * create: 2021-11-15
 * description: none
 * history:
 *   2021-11-15: new create
 */
export const Get = (url) => {
    const decoratorFunc = (target: any, propertyKey: string, { configurable, enumerable, value, writable }: PropertyDescriptor) => {
        const func = async (...args) => {
            const res = await (value as Function).apply(target,args);
            return res;
        }
        if(target.$restful){
            target.$restful[propertyKey] = {
                url,
                method: 'get'
            }
        }else{
            target.$restful = {
                [propertyKey]:{
                    url,
                    method: 'get'
                }
            }
        }
        return { configurable, enumerable, value: func, writable }
    }
    return decoratorFunc
}

export const Post = (url) => {
    const decoratorFunc = (target: any, propertyKey: string, { configurable, enumerable, value, writable }: PropertyDescriptor) => {
        const func = async (...args) => {
            const res = await (value as Function).apply(target,args);
            return res;
        }
        if(target.$restful){
            target.$restful[propertyKey] = {
                url,
                method: 'post'
            }
        }else{
            target.$restful = {
                [propertyKey]:{
                    url,
                    method: 'post'
                }
            }
        }
        return { configurable, enumerable, value: func, writable }
    }
    return decoratorFunc
}