import { Sequelize, ModelCtor, Model, Transaction } from 'sequelize'
import { tablesStructure, relation } from './tables'

export type TablesType = Record<keyof typeof tablesStructure, ModelCtor<Model<any, any>>>;
export type TablesKeyType = keyof typeof tablesStructure;

export const declareTables = (sequelize: Sequelize, cacheTabs: Array<any>, transition?: Transaction) => {
    const commonOpt = {
        freezeTableName: true,
        timestamps: false
    }
    let tables: any = {};
    if (cacheTabs && cacheTabs.length > 0) {
        // 按需初始化表
        cacheTabs.forEach((tableName: string) => {
            const model: ModelCtor<Model<any, any>> = (tablesStructure as any)[tableName]({ s: sequelize, o: commonOpt, t: tableName })
            if (transition) {
                tables[tableName] = useTransaction(model, transition)
            } else {
                tables[tableName] = model
            }
        })
    } else {
        Object.keys(tablesStructure).forEach((tableName: string) => {
            const model: ModelCtor<Model<any, any>> = (tablesStructure as any)[tableName]({ s: sequelize, o: commonOpt, t: tableName })
            if (transition) {
                tables[tableName] = useTransaction(model, transition)
            } else {
                tables[tableName] = model
            }
        })
    }
    relation(tables);
    return tables as Record<keyof typeof tablesStructure, ModelCtor<Model<any, any>>>;
}

// export type TablesType = ReturnType<typeof declareTables>

export const useTransaction = (model: ModelCtor<Model<any, any>>, transaction: Transaction) => {
    // 原始方法
    // model.addHook
    // model.addScope
    // model.afterBulkCreate
    // model.afterBulkDestroy
    // model.afterBulkSync
    // model.afterBulkUpdate
    // model.afterCreate
    // model.afterDestroy
    // model.afterFind
    // model.afterSave
    // model.afterSync
    // model.afterUpdate
    // model.afterValidate
    // model.aggregate
    // model.associations
    // model.beforeBulkCreate
    // model.beforeBulkDestroy
    // model.beforeBulkSync
    // model.beforeBulkUpdate
    // model.beforeCount
    // model.beforeCreate
    // model.beforeDestroy
    // model.beforeFind
    // model.beforeFindAfterExpandIncludeAll
    // model.beforeFindAfterOptions
    // model.beforeSave
    // model.beforeSync
    // model.beforeUpdate
    // model.beforeValidate
    // model.belongsTo
    // model.belongsToMany
    // model.build
    // model.bulkBuild
    // model.bulkCreate
    // model.count
    // model.create
    // model.decrement
    // model.describe
    // model.destroy
    // model.drop
    // model.findAll
    // model.findAndCountAll
    // model.findByPk
    // model.findCreateFind
    // model.findOne
    // model.findOrBuild
    // model.findOrCreate
    // model.getTableName
    // model.hasHook
    // model.hasHooks
    // model.hasMany
    // model.hasOne
    // model.increment
    // model.init
    // model.max
    // model.min
    // model.options
    // model.primaryKeyAttribute
    // model.primaryKeyAttributes
    // model.rawAttributes
    // model.removeAttribute
    // model.removeHook
    // model.restore
    // model.schema
    // model.scope
    // model.sequelize
    // model.sum
    // model.sync
    // model.tableName
    // model.truncate
    // model.unscoped
    // model.update
    // model.upsert
    const rewrite = {
        // 重写方法
        create: async (v, o) => await model.create(v, { transaction, ...o }),
        update: async (v, o) => await model.update(v, { transaction, ...o }),
        destroy: async (o) => await model.destroy({ transaction, ...o }),
        bulkCreate: async (vs, o) => await model.bulkCreate(vs, { transaction, ...o }),
        findAll: async (o) => await model.findAll({ transaction, ...o }),
        findOne: async (o) => await model.findOne({ transaction, ...o }),
        max: async (f, o) => await model.max(f, { transaction, ...o }),
        min: async (f, o) => await model.min(f, { transaction, ...o }),
        sum: async (f, o) => await model.sum(f, { transaction, ...o }),
    }
    return new Proxy(model, {
        get(target, propertyKey, receiver) {
            if (rewrite[propertyKey]) {
                return rewrite[propertyKey]
            } else {
                return Reflect.get(target, propertyKey, receiver)
            }
        }
    })
}
