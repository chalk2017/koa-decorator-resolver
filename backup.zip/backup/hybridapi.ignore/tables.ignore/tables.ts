import { Sequelize, STRING, INTEGER, BIGINT, DATE, TIME, BOOLEAN, FLOAT, DOUBLE, ModelCtor, Model } from 'sequelize'
import { TablesType } from './index'

//Create Tables
export const tablesStructure = {
    SIMULATION: (i: any) => i.s.define(i.t, {
        SIMULATION_ID: { 
          type: STRING(20),
          primaryKey: true,
        },
        COST_YEAR: { 
          type: STRING(4),
          primaryKey: true,
        },
        ACCOUNT_ID: STRING(50),
        SIM_START_DATE: DATE,
        SIM_END_DATE: DATE,
        CALENDAR_ID: STRING(1),
    }, i.o),
    COST: (i: any) => i.s.define(i.t, {
        SIMULATION_ID: { 
          type: STRING(20),
          primaryKey: true,
        },
        COST_YEAR: { 
          type: STRING(4),
          primaryKey: true,
        },
        COST_MONTH: { 
          type: STRING(2),
          primaryKey: true,
        },
        COST_TYPE: { 
          type: STRING(1),
          primaryKey: true,
        },
        PLAN_EXCHANGE_RATE: DOUBLE(17,5),
    }, i.o),
    COST_LABOR_DETAIL: (i: any) => i.s.define(i.t, {
        SIMULATION_ID: { 
          type: STRING(20),
          primaryKey: true,
        },
        COST_YEAR: { 
          type: STRING(4),
          primaryKey: true,
        },
        COST_MONTH: { 
          type: STRING(2),
          primaryKey: true,
        },
        COST_TYPE: { 
          type: STRING(1),
          primaryKey: true,
        },
        SEQ: { 
          type: INTEGER,
          primaryKey: true,
        },
        COST_WEEK: STRING(4),
        SN: STRING(20),
        BAND: STRING(20),
        RATE: DOUBLE(17,5),
        ASSIGN_WK_HOURS: DOUBLE(6,2),
        STATUS: STRING(1),
        EXPORT: STRING(20),
    }, i.o),
    COST_OTHER_DETAIL: (i: any) => i.s.define(i.t, {
        SIMULATION_ID: { 
          type: STRING(20),
          primaryKey: true,
        },
        COST_YEAR: { 
          type: STRING(4),
          primaryKey: true,
        },
        COST_MONTH: { 
          type: STRING(2),
          primaryKey: true,
        },
        COST_TYPE: { 
          type: STRING(1),
          primaryKey: true,
        },
        SEQ: { 
          type: INTEGER,
          primaryKey: true,
        },
        CHARGE_ITEM_ID: STRING(3),
        SN: STRING(20),
        CHARGE_DATE: DATE,
        CHARGE_CNY_AMT: DOUBLE(17,5),
        NOTE: STRING(500),
        STATUS: STRING(1),
    }, i.o),
    CHARGED_OUT: (i: any) => i.s.define(i.t, {
        ACCOUNT_ID: { 
          type: STRING(50),
          primaryKey: true,
        },
        COST_YEAR: { 
          type: STRING(4),
          primaryKey: true,
        },
        COST_MONTH: { 
          type: STRING(2),
          primaryKey: true,
        },
        COST_TYPE: { 
          type: STRING(1),
          primaryKey: true,
        },
        ACTUAL_EXCHANGE_RATE: DOUBLE(17,5),
    }, i.o),
    CHARGED_OUT_DETAIL: (i: any) => i.s.define(i.t, {
        ACCOUNT_ID: { 
          type: STRING(50),
          primaryKey: true,
        },
        COST_YEAR: { 
          type: STRING(4),
          primaryKey: true,
        },
        COST_MONTH: { 
          type: STRING(2),
          primaryKey: true,
        },
        COST_TYPE: { 
          type: STRING(1),
          primaryKey: true,
        },
        SEQ: { 
          type: INTEGER,
          primaryKey: true,
        },
        BU: STRING(50),
        BILLING_STATUS: STRING(50),
        ACTION_OWNER: STRING(50),
        FAIL_RECYCLE_REASON: STRING(50),
        LEDGER_MONTH_NUM: INTEGER,
        CAL_MONTH_NUM: INTEGER,
        USAGE_MONTH_NUM2: INTEGER,
        CHRG_COUNTRY_CD: STRING(50),
        CHRG_COMPANY_CD: STRING(50),
        WORK_ITEM_ID: STRING(50),
        ORIG_ICA_NUM: STRING(50),
        CHRG_ICA_NUM: STRING(50),
        CIAS_INVOICE_NUM: STRING(50),
        USAGE_QTY: DOUBLE(17,5),
        UNIT_PRICE_AMT: DOUBLE(17,5),
        TOT_CHRG_AMT: DOUBLE(17,5),
        ORIG_EMP_NUM: STRING(50),
        WEEK_ENDING_DATE: STRING(50),
        LEDGERFG_RECYCLETYPCD: STRING(50),
        PRICELST_ID: STRING(50),
        CHRG_METHOD_CD: STRING(50),
        CONTROL_GROUP_CD: STRING(50),
        ORIG_FA_CD: STRING(50),
        PROJECT_COUNTRY_CD: STRING(50),
        RATECLAS_CD: STRING(50),
        SOP_IND: STRING(50),
        ORIGDPTID: STRING(50),
        ACCT_TYP_CD: STRING(50),
        FINREL_FINDIV_CD: STRING(50),
        ACTIVITY_CD: STRING(50),
        PROD_SYS_ID: STRING(50),
        RPT_KEY: STRING(50),
        EMP_FIRST_NM: STRING(50),
        EMP_LAST_NM: STRING(50),
        MGR_SER_NUM: STRING(50),
        GEO: STRING(50),
        SECTOR: STRING(50),
        INDUSTRY: STRING(50),
        TYPE: STRING(50),
        SOURCE_KEY: STRING(50),
        PROJECT_ID: STRING(50),
        COST_CODE: STRING(50),
        COST_REF_NO: STRING(50),
        COMPANY_CODE: STRING(50),
        REMARK: STRING(50),
        BILLING: STRING(100),
        TYPE_OF_SERVICE: STRING(50),
        R_COST_TYPE: STRING(50),
    }, i.o),
    BALANCE_CHECK: (i: any) => i.s.define(i.t, {
        SIMULATION_ID: { 
          type: STRING(20),
          primaryKey: true,
        },
        COST_YEAR: { 
          type: STRING(4),
          primaryKey: true,
        },
        COST_MONTH: { 
          type: STRING(2),
          primaryKey: true,
        },
        COST_TYPE: { 
          type: STRING(1),
          primaryKey: true,
        },
        SEQ: { 
          type: INTEGER,
          primaryKey: true,
        },
        SN: STRING(20),
        ACTUAL_ASSIGN_HOURS: DOUBLE(6,2),
        ACTUAL_RATE: DOUBLE(17,5),
        CHARGE_ITEM_ID: STRING(3),
        ACTUAL_CNY_AMT: DOUBLE(17,5),
        CHECK_STATUS: STRING(1),
        CHARGE_DATE: STRING(8),
    }, i.o),
    ACCOUNT_CODE: (i: any) => i.s.define(i.t, {
        ACCOUNT_ID: { 
          type: STRING(50),
          primaryKey: true,
        },
        PROJECT_ID: { 
          type: STRING(50),
          primaryKey: true,
        },
        START_DATE: DATE,
        END_DATE: DATE,
        ACCOUNT_TYPE: STRING(20),
        CLOSE_DATE: DATE,
        STATUS: STRING(1),
        CALENDAR_ID: STRING(1),
        WORK_ITEM: STRING(50),
    }, i.o),
    PERSON: (i: any) => i.s.define(i.t, {
        SN: { 
          type: STRING(20),
          primaryKey: true,
        },
        FIRST_NAME: STRING(20),
        LAST_NAME: STRING(20),
        NAME_PINYIN: STRING(50),
        NAME_KANJI: STRING(50),
        NOTES_ID: STRING(100),
        MAIL_ADDRESS: STRING(100),
        FIRST_LINE_MANAGER_NOTES_ID: STRING(100),
        BAND: STRING(20),
        RATE_PRICE_CNY_AMT: DOUBLE(17,5),
        LOCATION: STRING(10),
        SECOND_LINE_MANAGER_NOTES_ID: STRING(100),
        EXPORT: STRING(20),
    }, i.o),
    CALENDAR: (i: any) => i.s.define(i.t, {
        CALENDAR_ID: { 
          type: STRING(1),
          primaryKey: true,
        },
        CALENDAR_TYPE: STRING(50),
    }, i.o),
    CALENDAR_HOLIDAY: (i: any) => i.s.define(i.t, {
        CALENDAR_ID: { 
          type: STRING(1),
          primaryKey: true,
        },
        CALENDAR_YEAR: { 
          type: STRING(4),
          primaryKey: true,
        },
        SEQ: { 
          type: INTEGER,
          primaryKey: true,
        },
        HOLIDAY: DATE,
        NAME: STRING(50),
        CHARGE_HOLIDAY: DATE,
    }, i.o),
    APP_SYSTEM_CONFIG: (i: any) => i.s.define(i.t, {
        ID: { 
          type: STRING(20),
          primaryKey: true,
        },
        CONFIG_TYPE: STRING(1),
        CONFIG_TEXT: STRING(200),
        CONFIG_NUM: DOUBLE(17,5),
        NOTE: STRING(50),
    }, i.o),
    ACCOUNT_BUDGET: (i: any) => i.s.define(i.t, {
        ACCOUNT_ID: { 
          type: STRING(50),
          primaryKey: true,
        },
        BUDGET_ID: { 
          type: STRING(20),
          primaryKey: true,
        },
        AVAILABLE_DATE: DATE,
        ACCOUNT_JPY_AMT: DOUBLE(17,5),
        EXCHANGE_RATE: DOUBLE(17,5),
        COST_YEAR: STRING(4),
    }, i.o),
    PROJECT: (i: any) => i.s.define(i.t, {
        PROJECT_ID: { 
          type: STRING(50),
          primaryKey: true,
        },
        PROJECT_NAME: STRING(100),
        START_DATE: DATE,
        END_DATE: DATE,
        CLIENT_NAME: STRING(100),
    }, i.o),
    UPLOAD_HISTORY: (i: any) => i.s.define(i.t, {
        UPLOAD_BILLING_REPORT_NAME: { 
          type: STRING(100),
          primaryKey: true,
        },
        UPLOAD_BILLING_REPORT_START_T: DATE,
        UPLOAD_BILLING_REPORT_END_T: DATE,
        UPLOAD_BILLING_REPORT_AMT_RATE: DOUBLE(17,5),
    }, i.o),
    CHARGE_ITEM: (i: any) => i.s.define(i.t, {
        CHARGE_ITEM_ID: { 
          type: STRING(3),
          primaryKey: true,
        },
        CHARGE_ITEM_NAME: STRING(50),
    }, i.o),
    V_COST: (i: any) => i.s.define(i.t, {
        SIMULATION_ID: { 
          type: STRING(20),
          primaryKey: true,
        },
        COST_YEAR: { 
          type: STRING(4),
          primaryKey: true,
        },
        COST_MONTH: { 
          type: STRING(2),
          primaryKey: true,
        },
        COST_TYPE: { 
          type: STRING(1),
          primaryKey: true,
        },
        PLAN_MONTH_CNY_AMT: DOUBLE(17,5),
        PLAN_EXCHANGE_RATE: DOUBLE(17,5),
    }, i.o),
    V_CHARGED_OUT: (i: any) => i.s.define(i.t, {
        ACCOUNT_ID: { 
          type: STRING(50),
          primaryKey: true,
        },
        COST_YEAR: { 
          type: STRING(4),
          primaryKey: true,
        },
        COST_MONTH: { 
          type: STRING(2),
          primaryKey: true,
        },
        COST_TYPE: { 
          type: STRING(1),
          primaryKey: true,
        },
        ACTUAL_MONTH_CNY_AMT: DOUBLE(17,5),
        ACTUAL_EXCHANGE_RATE: DOUBLE(17,5),
    }, i.o),
    V_PERSON_LABOR: (i: any) => i.s.define(i.t, {
      SN: { 
        type:STRING(20),
        primaryKey: true,
      },
      NAME_KANJI: STRING(50),
      BAND: STRING(20),
      EXPORT: STRING(20),
      RATE_PRICE_CNY_AMT: DOUBLE(17,5),
      SIMULATION_ID:{ 
        type: STRING(20),
        primaryKey: true,
      },
      ACCOUNT_ID: STRING(50),
      COST_YEAR: { 
        type: STRING(4),
        primaryKey: true,
      },
      COST_MONTH: { 
        type: STRING(2),
        primaryKey: true,
      },
      COST_TYPE: { 
        type: STRING(1),
        primaryKey: true,
      },
      SEQ: { 
        type: INTEGER,
        primaryKey: true,
      },
      COST_WEEK: STRING(4),
      ASSIGN_WK_HOURS: DOUBLE(6,2),
}, i.o),
}
//Create table relations
export const relation = (tables: TablesType) => {
    // tables?.ACCOUNT_CODE?.hasOne(tables?.ACCOUNT_BUDGET)
    // tables?.ACCOUNT_BUDGET?.belongsTo(tables?.ACCOUNT_CODE)
}
