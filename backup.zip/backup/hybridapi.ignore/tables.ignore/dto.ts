type String = string; type Date = string; type DOUBLE = number; type INTEGER = number;
// STRING, INTEGER, BIGINT, DATE, TIME, BOOLEAN, FLOAT, DOUBLE

export interface SIMULATION {
    SIMULATION_ID: String;
    COST_YEAR: String;
    ACCOUNT_ID?: String;
    SIM_START_DATE?: Date;
    SIM_END_DATE?: Date;
    CALENDAR_ID?: String;
}

export interface COST {
    SIMULATION_ID: String;
    COST_YEAR: String;
    COST_MONTH: String;
    COST_TYPE: String;
    PLAN_EXCHANGE_RATE?: DOUBLE;
}

export interface COST_LABOR_DETAIL {
    SIMULATION_ID: String;
    COST_YEAR: String;
    COST_MONTH: String;
    COST_TYPE: String;
    SEQ: INTEGER;
    COST_WEEK?: String;
    SN?: String;
    BAND?: String;
    RATE?: DOUBLE;
    ASSIGN_WK_HOURS?: DOUBLE;
    STATUS?: String;
    EXPORT?: String;
}

export interface COST_OTHER_DETAIL {
    SIMULATION_ID: String;
    COST_YEAR: String;
    COST_MONTH: String;
    COST_TYPE: String;
    SEQ: INTEGER;
    CHARGE_ITEM_ID?: String;
    SN?: String;
    CHARGE_DATE?: Date;
    CHARGE_CNY_AMT?: DOUBLE;
    NOTE?: String;
    STATUS?: String;
}

export interface CHARGED_OUT {
    ACCOUNT_ID: String;
    COST_YEAR: String;
    COST_MONTH: String;
    COST_TYPE: String;
    ACTUAL_EXCHANGE_RATE?: DOUBLE;
}

export interface CHARGED_OUT_DETAIL {
    ACCOUNT_ID: String;
    COST_YEAR: String;
    COST_MONTH: String;
    COST_TYPE: String;
    SEQ: INTEGER;
    BU?: String;
    BILLING_STATUS?: String;
    ACTION_OWNER?: String;
    FAIL_RECYCLE_REASON?: String;
    LEDGER_MONTH_NUM?: INTEGER;
    CAL_MONTH_NUM?: INTEGER;
    USAGE_MONTH_NUM2?: INTEGER;
    CHRG_COUNTRY_CD?: String;
    CHRG_COMPANY_CD?: String;
    WORK_ITEM_ID?: String;
    ORIG_ICA_NUM?: String;
    CHRG_ICA_NUM?: String;
    CIAS_INVOICE_NUM?: String;
    USAGE_QTY?: DOUBLE;
    UNIT_PRICE_AMT?: DOUBLE;
    TOT_CHRG_AMT?: DOUBLE;
    ORIG_EMP_NUM?: String;
    WEEK_ENDING_DATE?: String;
    LEDGERFG_RECYCLETYPCD?: String;
    PRICELST_ID?: String;
    CHRG_METHOD_CD?: String;
    CONTROL_GROUP_CD?: String;
    ORIG_FA_CD?: String;
    PROJECT_COUNTRY_CD?: String;
    RATECLAS_CD?: String;
    SOP_IND?: String;
    ORIGDPTID?: String;
    ACCT_TYP_CD?: String;
    FINREL_FINDIV_CD?: String;
    ACTIVITY_CD?: String;
    PROD_SYS_ID?: String;
    RPT_KEY?: String;
    EMP_FIRST_NM?: String;
    EMP_LAST_NM?: String;
    MGR_SER_NUM?: String;
    GEO?: String;
    SECTOR?: String;
    INDUSTRY?: String;
    TYPE?: String;
    SOURCE_KEY?: String;
    PROJECT_ID?: String;
    COST_CODE?: String;
    COST_REF_NO?: String;
    COMPANY_CODE?: String;
    REMARK?: String;
    BILLING?: String;
    TYPE_OF_SERVICE?: String;
    R_COST_TYPE?: String;
}

export interface BALANCE_CHECK {
    SIMULATION_ID: String;
    COST_YEAR: String;
    COST_MONTH: String;
    COST_TYPE: String;
    SEQ: INTEGER;
    SN?: String;
    ACTUAL_ASSIGN_HOURS?: DOUBLE;
    ACTUAL_RATE?: DOUBLE;
    CHARGE_ITEM_ID?: String;
    ACTUAL_CNY_AMT?: DOUBLE;
    CHECK_STATUS?: String;
    CHARGE_DATE?: String;
}

export interface ACCOUNT_CODE {
    ACCOUNT_ID: String;
    PROJECT_ID: String;
    START_DATE?: Date;
    END_DATE?: Date;
    ACCOUNT_TYPE?: String;
    CLOSE_DATE?: Date;
    STATUS?: String;
    CALENDAR_ID?: String;
    WORK_ITEM?: String;
}

export interface PERSON {
    SN: String;
    FIRST_NAME?: String;
    LAST_NAME?: String;
    NAME_PINYIN?: String;
    NAME_KANJI?: String;
    NOTES_ID?: String;
    MAIL_ADDRESS?: String;
    FIRST_LINE_MANAGER_NOTES_ID?: String;
    BAND?: String;
    RATE_PRICE_CNY_AMT?: DOUBLE;
    LOCATION?: String;
    SECOND_LINE_MANAGER_NOTES_ID?: String;
    EXPORT?: String;
}

export interface CALENDAR {
    CALENDAR_ID: String;
    CALENDAR_TYPE?: String;
}

export interface CALENDAR_HOLIDAY {
    CALENDAR_ID: String;
    CALENDAR_YEAR: String;
    SEQ: INTEGER;
    HOLIDAY?: Date;
    NAME?: String;
    CHARGE_HOLIDAY?: Date;
}

export interface APP_SYSTEM_CONFIG {
    ID: String;
    CONFIG_TYPE?: String;
    CONFIG_TEXT?: String;
    CONFIG_NUM?: DOUBLE;
    NOTE?: String;
}

export interface ACCOUNT_BUDGET {
    ACCOUNT_ID: String;
    BUDGET_ID: String;
    AVAILABLE_DATE?: Date;
    ACCOUNT_JPY_AMT?: DOUBLE;
    EXCHANGE_RATE?: DOUBLE;
    COST_YEAR?: String;
}

export interface PROJECT {
    PROJECT_ID: String;
    PROJECT_NAME?: String;
    START_DATE?: Date;
    END_DATE?: Date;
    CLIENT_NAME?: String;
}

export interface UPLOAD_HISTORY {
    UPLOAD_BILLING_REPORT_NAME: String;
    UPLOAD_BILLING_REPORT_START_T?: Date;
    UPLOAD_BILLING_REPORT_END_T?: Date;
    UPLOAD_BILLING_REPORT_AMT_RATE?: DOUBLE;
}

export interface CHARGE_ITEM {
    CHARGE_ITEM_ID: String;
    CHARGE_ITEM_NAME?: String;
}

export interface V_COST {
    SIMULATION_ID: String;
    COST_YEAR: String;
    COST_MONTH: String;
    COST_TYPE: String;
    PLAN_MONTH_CNY_AMT?: DOUBLE;
    PLAN_EXCHANGE_RATE?: DOUBLE;
}

export interface V_CHARGED_OUT {
    ACCOUNT_ID: String;
    COST_YEAR: String;
    COST_MONTH: String;
    COST_TYPE: String;
    ACTUAL_MONTH_CNY_AMT?: DOUBLE;
    ACTUAL_EXCHANGE_RATE?: DOUBLE;
}

export interface V_PERSON_LABOR {
    SN: String,
    NAME_KANJI?: String,
    BAND?: String,
    EXPORT?: String,
    RATE_PRICE_CNY_AMT?: DOUBLE,
    SIMULATION_ID?: String,
    ACCOUNT_ID?: String,
    COST_YEAR?: String,
    COST_MONTH?: String,
    COST_TYPE?: String,
    SEQ?: INTEGER,
    COST_WEEK?: String,
    ASSIGN_WK_HOURS?: DOUBLE,
}
