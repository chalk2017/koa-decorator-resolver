import * as fs from 'fs'
import * as path from 'path'
import * as xlsx from 'xlsx'

export type UploadOption = { parser?: 'xlsx', dir?: '', backup?: {} };

const resPath = path.resolve(path.join('src', 'resource', 'reports'))

export const upload = async (ctx: any, option?: UploadOption) => {
    // console.log(ctx)
    // let file = ctx.request.file; // 获取上传文件
    const res = { url: null, data: null }
    option = option || {}
    try {
        // buffer写入，只能写小文件
        const fileName = ctx.request.files['uploadFile'].name
        const fb = fs.readFileSync(ctx.request.files['uploadFile']['path'])
        const fw = fs.writeFileSync(path.join(option.dir || resPath, fileName), fb)
        // const fileName: string = await new Promise((resolve, reject) => {
        //     try {
        //         // 管道写入，文件始终被占用
        //         // 创建可读流
        //         const fsInput = fs.createReadStream(ctx.request.files['uploadFile']['path']);
        //         const fileName = ctx.request.files['uploadFile'].name
        //         // 创建可写流
        //         const fsOutput = fs.createWriteStream(path.join(resPath, fileName));
        //         // 可读流通过管道写入可写流
        //         fsInput.pipe(fsOutput);
        //         // 管道通信结束
        //         fsOutput.end(() => {
        //             fsInput.close()
        //             fsOutput.close()
        //             resolve(fileName)
        //         })
        //     } catch (err) {
        //         console.log(err)
        //         reject(err)
        //     }
        // })
        res.url = path.join(resPath, fileName)
        res.data = JSON.parse(ctx.request.body.props)
        // 调用解析器
        if (option.parser === 'xlsx') {
            type Res = { url: string, xlsx: xlsx.WorkSheet, data: any }
            const exl = xlsx.readFile(res.url);
            (res as Res).xlsx = exl
            return res as Res
        } else {
            return res
        }
    } catch (err) {
        console.log(err)
        res.url = null
        return res
    }
}
