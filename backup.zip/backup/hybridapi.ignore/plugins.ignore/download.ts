import * as fs from 'fs'
import * as path from 'path'
import * as xlsx from 'xlsx'
import * as send from 'koa-send';

export type DownloadOption = { type?: 'path' | 'stream', dir?: '' };

export const downloadBefore = async (ctx: any, option?: DownloadOption) => {
    const res = { url: null, data: null }
    option = option || {}
    try {
        const headerStr = ctx.request.header;
        return headerStr;
    } catch (err) {
        console.log(err)
        return null
    }
}

export const downloadAfter = async (res: any, ctx: any, option?: DownloadOption) => {
    option = option || {}
    const type = option.type || 'path'
    try {
        // ctx.attachment(res);
        if (type === 'path') {
            if (option.dir) {
                await send(ctx, res, { root: option.dir });
            } else {
                await send(ctx, res);
            }
        } else if (type === 'stream') {
            // ctx.body = fs.createReadStream(path)
            ctx.body = res;
        }
    } catch (err) {
        console.log(err)
    }
}
