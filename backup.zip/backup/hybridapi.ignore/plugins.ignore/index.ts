import { injectorBuilder, Injector } from '../common/inject.ts';
import { upload, UploadOption } from './upload';
import { downloadBefore, downloadAfter, DownloadOption } from './download';
// 声明装饰器
export const Upload: Injector<UploadOption> = injectorBuilder('Upload')
export const Download: Injector<DownloadOption> = injectorBuilder('Download')
// 装饰器配置
export const config = {
    'Upload': { // 装饰器名称
        'before': { // 前拦截器
            plugin: upload, // 插件函数
            replaceProps: true, // 是否替换参数
        }
    },
    'Download': {
        'method': 'get', // 默认post
        'before': {
            plugin: downloadBefore,
            replaceProps: true,
        },
        'after': {
            plugin: downloadAfter,
            replaceProps: false,
        }
    },
    // 'Crawl': { // 爬虫
    //     'before': {
    //         plugin: (ctx, { option }) => "",
    //         replaceProps: true,
    //     }
    // },
    // 'Verify': { // 登录权限校验
    //     'before': {
    //         plugin: (ctx, { option }) => "",
    //         replaceProps: true,
    //     }
    // },
}