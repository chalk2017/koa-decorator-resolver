import * as path from 'path'
export const drivers = [
    'mysql', 'postgre', 'sqlite'
]

export const loadConfig = () => {
    const { parsed } = require('dotenv').config()
    if (parsed.DB_DRIVER === 'sqlite') {
        const sqliteConfig = require(path.resolve('db.sqlite.js'))
        return [{
            dialect: 'sqlite',
            storage: sqliteConfig.path
        }]
    } else if (parsed.DB_DRIVER === 'mysql') {
        const mysqlConfig = require(path.resolve('db.mysql.js'))
        return [mysqlConfig.database, mysqlConfig.username, mysqlConfig.password, {
            host: mysqlConfig.host,
            port: mysqlConfig.port,
            dialect: 'mysql',
        }]
    } else if (parsed.DB_DRIVER === 'postgre') {
        return null
    } else {
        return null
    }
}

