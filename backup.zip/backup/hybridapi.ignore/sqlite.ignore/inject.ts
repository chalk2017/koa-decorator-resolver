/**
 * author: Chalk Yu
 * create: 2021-11-07
 * description: none
 * history:
 *   2021-11-07: new create
 */
import { connection, ormConnection } from './conn';
import { declareTables, TablesKeyType } from '../tables';
import { Sequelize } from 'sequelize'

interface Option {
    useOrm?: boolean,
    autoClose?: boolean,
    useTransaction?: boolean,
    tables?: Array<TablesKeyType>
}

export const Sqlite = (option?: Option) => {
    const decoratorFunc = (target: any, propertyKey: string, { configurable, enumerable, value, writable }: PropertyDescriptor) => {
        const func = async (...args: any) => {
            const autoClose = option?.autoClose ?? true; // 自动关闭，默认true
            const useTransaction = option?.useTransaction ?? false; // 是否使用事物，默认false
            let res!: any;
            if (option?.useOrm) {
                const sequelize = await ormConnection();
                let transaction = null;
                if (useTransaction) {
                    transaction = await sequelize.transaction();
                }
                const tables = declareTables(sequelize as Sequelize, option.tables, transaction);
                target.db = { sequelize, tables, transaction };
                try{
                    res = await (value as Function).apply(target, args);
                    if (useTransaction) {
                        transaction.commit();
                    }
                }catch(err){
                    transaction.rollback();
                    throw err;
                }
                // res = await (value as Function).apply(target, args);
                if (autoClose && !useTransaction) {
                    await sequelize.close();
                }
            } else {
                const conn = await connection();
                target.db = conn;
                res = await (value as Function).apply(target, args);
                if (autoClose) {
                    await conn.close();
                }
            }
            return res;
        }
        return { configurable, enumerable, value: func, writable }
    }
    return decoratorFunc
}
