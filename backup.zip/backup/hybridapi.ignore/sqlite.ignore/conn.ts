/**
 * author: Chalk Yu
 * create: 2021-11-07
 * description: none
 * history:
 *   2021-11-07: new create
 */

import * as sqlite3 from 'sqlite3'
import { open, Database } from 'sqlite'
import { Sequelize, Transaction } from 'sequelize'
import { loadConfig, drivers } from './switcher'
import { TablesType } from '../tables'
// import { sqlitePath } from '../globalConst'

export type DB = any;
export type ConnectionType = Database<sqlite3.Database, sqlite3.Statement>;
export const connection = async () => {
    try {
        const db: ConnectionType = await open({
            filename: require(require('path').resolve('db.sqlite.js')).path,
            driver: sqlite3.Database
        })
        return db
    } catch (err) {
        new Error('DB connect error!')
    }
}

export type OrmConnectionType = { sequelize: Sequelize, tables: TablesType, transaction: Transaction }
export const ormConnection = async () => {
    try {
        let sqliteConfig: any = [{
            dialect: 'sqlite',
            storage: require(require('path').resolve('db.sqlite.js')).path
        }]
        if (drivers.length > 0) {
            const commonConfig = loadConfig()
            if (commonConfig) {
                sqliteConfig = commonConfig
                console.log('==================', commonConfig)
            }
        }
        const sequelize: Sequelize = new Sequelize(...sqliteConfig);
        return sequelize
    } catch (err) {
        new Error('DB connect error!')
    }
}