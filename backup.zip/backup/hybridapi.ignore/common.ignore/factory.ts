import { config } from '../plugins/index';

// 装饰器绑定属性
export const injectBind = (classObj: any, funcName: string, options: { [injectName: string]: any }) => {
    if (!classObj.$inject) {
        classObj.$inject = {}
    }
    for (const injectName in options) {
        if (classObj.$inject[injectName]) {
            // 绑定函数，多装饰器绑定
            classObj.$inject[injectName][funcName] = options[injectName]
        } else {
            classObj.$inject[injectName] = {
                [funcName]: options[injectName]
            }
        }
    }
}
// 装饰器解除属性绑定
export const injectRemove = (classObj: any, injectName: string, funcName?: string) => {
    if (!classObj.$inject) {
        classObj.$inject = {}
    }
    if (classObj.$inject[injectName]) {
        if (funcName) {
            delete classObj.$inject[injectName][funcName]
        } else {
            delete classObj.$inject[injectName]
        }
    }
}
// 自动注入
/**
 * service方法参数：
 * arg1：页面传输参数
 * arg2：插件参数 + 页面传输参数
 * arg3：请求交互的ctx对象
 */
export const servInjector = (target: any, funcName: string) => {
    // 默认post
    let method = 'post';
    // 插件中如果有get优先get请求
    for (const injectName in config) {
        // 插件有指定method
        if (config[injectName].method) {
            // 插件是绑定在当前的函数上
            if (target?.$inject && target?.$inject[injectName] && target?.$inject[injectName][funcName]) {
                // 指定插件的method
                method = config[injectName].method;
                break;
            }
        }
    }
    //
    const controller = async (ctx: any) => {
        type FullResType = {
            data: any,
            [injectName: string]: any
        }
        const fullRes = {} as FullResType // 插件返回值
        let data = null as any;
        // 前拦截器
        for (const injectName in config) {
            // 只处理注解的对象
            if (!config[injectName].before) continue
            const pluginFunction = config[injectName].before.plugin
            if (target?.$inject && target?.$inject[injectName] && target?.$inject[injectName][funcName]) {
                const pluginRes = await pluginFunction(ctx, target?.$inject[injectName][funcName]?.option)
                fullRes[injectName] = pluginRes
                // 替换第一个参数
                if (config[injectName].before.replaceProps) {
                    data = pluginRes
                }
            }
            // if (config[injectName].replaceProps) {
            //     // 异步方法解析
            //     if (Object.prototype.toString.call(pluginFunction) === '[object AsyncFunction]') {
            //         data = await pluginFunction(ctx, target?.$inject[injectName][funcName])
            //     } else {
            //         // 同步方法解析
            //         data = pluginFunction(ctx, target?.$inject[injectName][funcName])
            //     }
            // } else {
            //     if (Object.prototype.toString.call(pluginFunction) === '[object AsyncFunction]') {
            //         await pluginFunction(ctx, target?.$inject[injectName][funcName])
            //     } else {
            //         pluginFunction(ctx, target?.$inject[injectName][funcName])
            //     }
            // }
        }
        fullRes.data = ctx.request.body;
        if (data === null) {
            data = fullRes.data;
        }
        // 逻辑处理
        let res = await target[funcName](data, fullRes, ctx);
        // 后拦截器
        let hasAfterInjector = false;
        for (const injectName in config) {
            // 只处理注解的对象
            if (!config[injectName].after) continue
            const pluginFunction = config[injectName].after.plugin
            if (target?.$inject && target?.$inject[injectName] && target?.$inject[injectName][funcName]) {
                const pluginRes = await pluginFunction(res, ctx, target?.$inject[injectName][funcName]?.option)
                fullRes[injectName] = pluginRes
                hasAfterInjector = true // 有后拦截器的情况
                // 替换第一个参数
                if (config[injectName].after.replaceProps) {
                    // 如果有后拦截器，用后拦截器的结构填充body
                    ctx.body = pluginRes
                }
            }
        }
        // 如果没有后拦截器，用body填充res
        if (!hasAfterInjector) {
            ctx.body = res;
        }
    }
    return [method, controller]
}
