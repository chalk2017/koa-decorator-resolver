import { injectBind } from './factory.ts';
// 装饰器类型声明
export type Injector<T> = (option?: T) => any
export const injectorBuilder = (injectName, callbacks?: { onCreate, onBefore, onAfter }) => {
    const onCreate = callbacks?.onCreate || (() => ""); // 装饰器声明时
    const onBefore = callbacks?.onBefore || ((...args) => args); // 函数调用前
    const onAfter = callbacks?.onAfter || ((res) => res); // 函数调用后
    const Injector = (option?: any) => {
        const decoratorFunc = (target: any, propertyKey: string, { configurable, enumerable, value, writable }: PropertyDescriptor) => {
            onCreate(target, propertyKey);
            const func = async (...args) => {
                const _args = await onBefore(...args);
                const _res = await (value as Function).apply(target, _args);
                const res = await onAfter(_res)
                return res;
            }
            injectBind(target, propertyKey, {
                [injectName]: { option } // 对应 plugins/index.config 下的key名
            })
            return { configurable, enumerable, value: func, writable }
        }
        return decoratorFunc
    }
    return Injector;
}
