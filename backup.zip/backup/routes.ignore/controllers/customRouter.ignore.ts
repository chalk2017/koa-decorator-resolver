/**
 * author: Chalk Yu
 * create: 2021-11-15
 * description: none
 * history:
 *   2021-11-15: new create
 */
import { router } from '..';
import * as serviceModules from '../../controllers';
let controllers = {}
for (let name in serviceModules) {
    const serviceModule = serviceModules[name];
    // 获取模块函数名
    const moduleFuncs = Object.getOwnPropertyNames(serviceModule.prototype).filter((f) => f !== 'constructor' && f !== '$restful');
    // 实例化模块
    const moduleObj = Reflect.construct(serviceModule, [])
    for (let subName of moduleFuncs) {
        const { url, method } = moduleObj.$restful[subName]
        const controller = async (ctx: any) => {
            if (method?.toLowerCase() === 'get') {
                const { params } = ctx
                const res = await moduleObj[subName](params || {}, ctx);
                ctx.body = res;
            } else if (method?.toLowerCase() === 'post') {
                const data = ctx.request.body;
                const res = await moduleObj[subName](data, ctx);
                ctx.body = res;
            } else if (method?.toLowerCase() === 'put') {
                const data = ctx.request.body;
                const res = await moduleObj[subName](data, ctx);
                ctx.body = res;
            } else if (method?.toLowerCase() === 'delete') {
                const { params } = ctx
                const res = await moduleObj[subName](params || {}, ctx);
                ctx.body = res;
            } else {
                return await moduleObj[subName](ctx);
            }
        }
        if (method?.toLowerCase() === 'get') {
            router.get(url, controller)
        } else if (method?.toLowerCase() === 'post') {
            router.post(url, controller)
        } else if (method?.toLowerCase() === 'put') {
            router.put(url, controller)
        } else if (method?.toLowerCase() === 'delete') {
            router.delete(url, controller)
        } else {
            router[method](url, controller)
        }
        // console.log(`/${name}/${subName}`)
        controllers[`${url}`] = controller;
    }
}
export { controllers }