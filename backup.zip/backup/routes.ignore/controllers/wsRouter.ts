/**
 * author: Chalk Yu
 * create: 2021-11-04
 * description: none
 * history:
 *   2021-11-04: new create
 */
import { router } from '..';
import { print } from '../../util/console';
import { wsConnStore } from '../../routes/ws';
const wsUserSending = async (ctx: any) => {
    let { xxx } = ctx.request.body;
    try {
        wsConnStore[0].websocket.send(JSON.stringify({ from: 'service', message: 'restful callback sending!' }))
        ctx.body = "send success!";
    } catch (err) {
        print.error(String(err))
        ctx.status = 500;
    }
}
router.post('/wsUserSending', wsUserSending);

export { wsUserSending };