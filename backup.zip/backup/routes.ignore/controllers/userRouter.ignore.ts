/**
 * author: Chalk Yu
 * create: 2021-11-15
 * description: none
 * history:
 *   2021-11-15: new create
 */
import { router } from '..';
import * as serviceModules from '../../services';
import { servInjector } from '@hybridapi/common/factory';
let controllers = {}
// router.post('/ExampleService/add',async (res:any) => {
//     console.log(res)
//     res.body = {version:2}
// })
for (let name in serviceModules) {
    const serviceModule = serviceModules[name];
    // 获取模块函数名
    const moduleFuncs = Object.getOwnPropertyNames(serviceModule.prototype).filter((f) => f !== 'constructor' && f !== '$inject');
    // const moduleFuncs = Object.getOwnPropertyNames(serviceModule.prototype).filter((f) => f !== 'constructor');
    // 实例化模块
    const moduleObj = Reflect.construct(serviceModule, [])
    for (let subName of moduleFuncs) {
        // const controller = async (ctx: any) => {
        //     const data = ctx.request.body;
        //     const res = await moduleObj[subName](data, ctx);
        //     ctx.body = res;
        // }
        const [method, controller] = servInjector(moduleObj, subName);
        router[method](`/${name}/${subName}`, controller);
        // console.log(`/${name}/${subName}`)
        controllers[`${name}_${subName}`] = controller;
    }
}
export { controllers }