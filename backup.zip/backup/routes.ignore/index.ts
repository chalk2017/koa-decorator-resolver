/**
 * author: Chalk Yu
 * create: 2021-11-04
 * description: none
 * history:
 *   2021-11-04: new create
 */
import * as Router from 'koa-router';

const router = new Router();

router.get('/', (ctx: any) => {
    ctx.body = 'Hello world.'
});

require('require-all')({
    dirname: __dirname + '/controllers',
    filter: /.*.ts$/,
});

export { router as wsRouter, wsConnStore } from './ws';
export { router };
export default router;