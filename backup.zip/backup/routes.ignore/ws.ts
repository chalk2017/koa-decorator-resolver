/**
 * author: Chalk Yu
 * create: 2021-11-04
 * description: none
 * history:
 *   2021-11-04: new create
 */
import * as Router from 'koa-router';

const router = Router();

let wsConnStore = {}

router.all('/koa/ws', (ctx: any) => {

    const { user } = ctx.query

    wsConnStore[user] = ctx;

    ctx.websocket.send('connection success!');

    ctx.websocket.on('message', function (message: any) {
        console.log('message-->', message);
        const channel = JSON.parse(message).channel;
        console.log('channel-->', channel);
        ctx.websocket.send(JSON.stringify({ from: 'BFF', message: 'callback sending!' }));
    });
})

export { router, wsConnStore };
export default router;